<?php
/**
 * Plugin Name: Guliwera – diagnostyka płatności (tymczasowa)
 * Description: Jednorazowo zapisuje raport ustawień bramek płatności (bez kluczy) w szkicu strony „Diagnostyka płatności”. Do usunięcia po użyciu.
 * Version: 1.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'wp_loaded', function () {
	if ( get_option( 'gk_diag_pl_done' ) || ! function_exists( 'WC' ) ) { return; }
	update_option( 'gk_diag_pl_done', 1 );
	$r = array();
	$r[] = 'Waluta: ' . get_option( 'woocommerce_currency' ) . ' | kraj: ' . get_option( 'woocommerce_default_country' ) . ' | WC ' . WC()->version;
	$st = get_option( 'woocommerce_stripe_settings', array() );
	$safe = array();
	foreach ( (array) $st as $k => $v ) {
		if ( preg_match( '/secret|key|token|password|webhook_secret/i', $k ) ) { $safe[ $k ] = $v ? '[ustawione]' : '[puste]'; continue; }
		$safe[ $k ] = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
	}
	$r[] = 'Stripe settings: ' . wp_json_encode( $safe, JSON_UNESCAPED_UNICODE );
	foreach ( array( 'wcstripe_account_data', '_wcstripe_feature_upe', 'wc_stripe_wh_monitor_began_at' ) as $o ) {
		$v = get_option( $o );
		if ( is_array( $v ) ) { $v = array_intersect_key( $v, array_flip( array( 'id', 'country', 'default_currency', 'charges_enabled', 'payouts_enabled', 'details_submitted', 'capabilities', 'requirements' ) ) ); }
		$r[] = $o . ': ' . wp_json_encode( $v, JSON_UNESCAPED_UNICODE );
	}
	foreach ( get_option( 'wcstripe_account_data', array() ) ? array() : array() as $x ) {}
	$gws = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
	foreach ( $gws as $id => $g ) {
		$avail = 'n/d';
		try { $avail = $g->is_available() ? 'TAK' : 'NIE'; } catch ( \Throwable $e ) { $avail = 'błąd: ' . $e->getMessage(); }
		$r[] = 'Bramka ' . $id . ' | enabled=' . $g->enabled . ' | is_available=' . $avail . ' | tytuł=' . $g->get_title();
	}
	$r[] = 'Aktywne wtyczki: ' . implode( ', ', (array) get_option( 'active_plugins' ) );
	wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'draft', 'post_title' => 'Diagnostyka płatności', 'post_content' => '<!-- wp:html --><pre>' . esc_html( implode( "\n\n", $r ) ) . '</pre><!-- /wp:html -->' ) );
}, 99 );
